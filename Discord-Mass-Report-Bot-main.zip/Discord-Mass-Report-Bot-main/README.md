# Discord Mass Report Tool
Repeatedly reports a user on Discord.

## Information
This tool was strictly developed to demonstrate how straightforward it can be to spam a service like Discord. "Report bots" tend to increase the chances in account terminations. Please refrain from using this Discord report bot as it is, once again, developed for educational purposes only. Nevertheless, if you use this, you are doing it at your own risk. You have been warned.

## Preview
![](https://media.discordapp.net/attachments/833819785405923351/834156428591497246/unknown.png?width=540&height=430)<br>

## Usage
- Python 3.8 or above is required.
- I develop for Windows machines only and do not intentionally support other operating systems.
- If the bot doesn't work then open command panel and type pip install colorama


1. Run main.py.
2. Paste the Discord Token
3. Discord server's ID the message was posted in.
4. Paste the channel ID.
5. Paste the message ID.
6. Select a reasonable reason to the report.
7. All set!

